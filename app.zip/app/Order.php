<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Lab;

class Order extends Model
{
    protected $guarded = [];
    protected $table ='orders';

    
}
