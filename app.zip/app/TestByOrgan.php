<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TestByOrgan extends Model
{
    protected $guarded = [];
   
    protected $table ='findtestbyorgan';
}
