@include('admin.layouts.header')
@include('admin.layouts.sidebar')
<div class="main-content">
    @yield('content')
</div>
@include('admin.layouts.footer')