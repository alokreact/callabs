Dear {{ $mailData['name'] }},
<p>Thank you for booking your appointment with our Hospital.</p>
<p>The details of your appointment are below:</p>
<p>Date: {{ $mailData['date'] }}</p>
<p>Time: {{ $mailData['time'] }}</p>
<p>Doctor: {{ $mailData['doctorName'] }}</p>
<br>
Location: 313 No Name Road, California, 14152
<br>
Contact: 123 213-1234
