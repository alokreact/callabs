<link href="<?php echo e(('css/banner.css')); ?>" rel="stylesheet">

<section>
	<div class="customer-feedback">
		<div class="container text-center">
			 
			<div class="row">
				<div class=" col-md-7  col-sm-8">
					
                <div class="owl-carousel feedback-slider">

						<!-- slider item -->
						<div class="feedback-slider-item">
						<div class="tag banner-topright"></div>
	
						<img src="img/boxes/fire-96.png" class="center-block img-circle" alt="Customer Feedback">

							<h3 class="customer-name">Lipid Profile at 1200</h3>
							<h3 class="customer-name">FLAT 50% OFF</h3>
						
							<p>Now Staying Healthy is Pocket Friendly.</p>


							<input type="submit" value="Book Now" class="btn btn-skin btn-block btn-lg">
									
							<span class="light-bg customer-rating" data-rating="5">
								5
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->

						<!-- slider item -->
						<div class="feedback-slider-item">
						<div class="tag banner-topright"></div>
	
							<img src="img/boxes/fire-96.png" class="center-block img-circle" alt="Customer Feedback">
							 <h3 class="customer-name"></h3>
							<p>    
								
							
							.</p> 
							<span class="light-bg customer-rating" data-rating="4">
								4
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->

						<!-- slider item -->
						<div class="feedback-slider-item">
						<div class="tag banner-topright"></div>
	
							<img src="img/boxes/fire-96.png" class="center-block img-circle" alt="Customer Feedback">
							<!-- <h3 class="customer-name">Md Nahidul</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. It is a long established fact that a reader will be distracted by the readable its layout.</p> -->
							<span class="light-bg customer-rating" data-rating="5">
								5
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->

					</div><!-- /End feedback-slider -->

					<!-- side thumbnail -->
					<!-- <div class="feedback-slider-thumb hidden-xs">
						<div class="thumb-prev">
							<span>
								<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/451270/profile/profile-80.jpg" alt="Customer Feedback">
							</span>
							<span class="light-bg customer-rating">
								5
								<i class="fa fa-star"></i>
							</span>
						</div>

						<div class="thumb-next">
							<span>
								<img src="https://res.cloudinary.com/hnmqik4yn/image/upload/c_fill,fl_force_strip,h_128,q_100,w_128/v1493982718/ah57hnfnwxkmsciwivve.jpg" alt="Customer Feedback">
							</span>
							<span class="light-bg customer-rating">
								4
								<i class="fa fa-star"></i>
							</span>
						</div>
					</div> -->
					<!-- /side thumbnail -->

				</div><!-- /End col -->
			</div><!-- /End row -->
		</div><!-- /End container -->
	</div><!-- /End customer-feedback -->
</section>

<!-- extra -->
 <?php /**PATH C:\xampp\htdocs\callabs\resources\views/layouts/components/banner.blade.php ENDPATH**/ ?>