

<?php $__env->startSection('content'); ?>


<link href="<?php echo e(('css/package-detail.css')); ?>" rel="stylesheet">
<div class="pd-wrap" style="margin-top: 200px;">

    <div class="container" style="background-color: #fffbfa; width:80%">



        <div class="jumbotron col-md-10" style="left:8%">
            <div class="row">

                <div class="col-md-7" style="height:115px">

                    <h4 class="blue" style="color:#03A853;padding:15px;font-size:24px;font-weight:bold;">Comprehensive Gold Full Body Checkup

                        <br /><br /><span class="blue" style="color:#000;padding:6px;line-height: 25px;font-size:16px">Include 40 Tests</span>
                    </h4>


                </div>
                <div class="col-md-3">

                    <h4 class="blue" style="color:#03A853;padding:15px;position:absolute;right:-50%;font-weight:bold">Price 999/- </h4>
                    <br />
                    <br />
                    <h5 class="blue" style="padding:10px;padding:15px;position:absolute;right:-40%;color:#ff6f61;font-weight:bold;font-size:18px">Add To Cart</h5>


                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-md-7 left-package">

                <p class="details-para" style="text-align: justify;color:#000; line-height:30px;padding:12px">

                    Unhealthy lifestyle and stress can gradually take a toll on our
                    health. Early detection can help to capture the warning signs of masked diseases in the body.
                    Comprehensive Gold Full Body Checkup Package provides a comprehensive range of tests that check your liver, heart & kidney function, blood sugar, thyroid status, lipid profile, blood counts, vitamins, minerals, urine and more. In addition to all the features of Comprehensive Silver Full Body Checkup Package, it also provides C-Reactive Protein, Rheumatoid Factor, Hepatitis B and more detailed urine examination. This package – a part of our ‘premium range’ of diagnostic tests – can be ordered once every 6 to 12 months or as recommended by your doctor..</p>






                <div class="container">
                    <div class="row">
                        <div class="text-center">
                            <h2 style="color:#03A853;font-size: 24px;font-weight:bold">Comprehensive Gold Full Body Checkup </h2>
                        </div>
                    </div>

                    <div class="col-md-12" style="left:8%">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="pxlr-club-faq">
                                    <div class="content">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                            <div class="panel panel-default">
                                                <div class="panel-heading" id="headingOne" role="tab">
                                                    <h4 class="panel-title">
                                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">01.
                                                            Anonymous user won’t receive
                                                            email if question is private? <i class="pull-right fa fa-plus"></i></a>
                                                    </h4>
                                                </div>
                                                <div class="panel-collapse collapse" id="collapseOne" role="tabpanel" aria-labelledby="headingOne">
                                                    <div class="panel-body pxlr-faq-body">
                                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life
                                                            accusamus terry richardson ad squid. 3 wolf moon officia
                                                            aute,
                                                            non cupidatat skateboard dolor brunch. Food truck quinoa
                                                            nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                                                            aliqua
                                                            put a bird on it squid single-origin coffee nulla assumenda
                                                            shoreditch et. Nihil anim keffiyeh helvetica, craft beer
                                                            labore
                                                            wes anderson cred nesciunt sapiente ea proident. Ad vegan
                                                            excepteur butcher vice lomo. Leggings occaecat craft beer
                                                            farm-to-table, raw denim aesthetic synth nesciunt you
                                                            probably
                                                            haven't heard of them accusamus labore sustainable VHS.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading" id="headingTwo" role="tab">
                                                    <h4 class="panel-title">
                                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">02. How to
                                                            have
                                                            an editor like this editor here for Q&A plugin? <i class="pull-right fa fa-plus"></i></a>
                                                    </h4>
                                                </div>
                                                <div class="panel-collapse collapse" id="collapseTwo" role="tabpanel" aria-labelledby="headingTwo">
                                                    <div class="panel-body pxlr-faq-body">
                                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life
                                                            accusamus terry richardson ad squid. 3 wolf moon officia
                                                            aute,
                                                            non cupidatat skateboard dolor brunch. Food truck quinoa
                                                            nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                                                            aliqua
                                                            put a bird on it squid single-origin coffee nulla assumenda
                                                            shoreditch et. Nihil anim keffiyeh helvetica, craft beer
                                                            labore
                                                            wes anderson cred nesciunt sapiente ea proident. Ad vegan
                                                            excepteur butcher vice lomo. Leggings occaecat craft beer
                                                            farm-to-table, raw denim aesthetic synth nesciunt you
                                                            probably
                                                            haven't heard of them accusamus labore sustainable VHS.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading" id="headingThree" role="tab">
                                                    <h4 class="panel-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">03. Problem
                                                            with Knowledge base Article and knowledge base setting? <i class="pull-right fa fa-plus"></i></a></h4>
                                                </div>
                                                <div class="panel-collapse collapse" id="collapseThree" role="tabpanel" aria-labelledby="headingThree">
                                                    <div class="panel-body pxlr-faq-body">
                                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life
                                                            accusamus terry richardson ad squid. 3 wolf moon officia
                                                            aute,
                                                            non cupidatat skateboard dolor brunch. Food truck quinoa
                                                            nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                                                            aliqua
                                                            put a bird on it squid single-origin coffee nulla assumenda
                                                            shoreditch et. Nihil anim keffiyeh helvetica, craft beer
                                                            labore
                                                            wes anderson cred nesciunt sapiente ea proident. Ad vegan
                                                            excepteur butcher vice lomo. Leggings occaecat craft beer
                                                            farm-to-table, raw denim aesthetic synth nesciunt you
                                                            probably
                                                            haven't heard of them accusamus labore sustainable VHS.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="pxlr-club-faq">
                                    <div class="content">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                            <div class="panel panel-default">
                                                <div class="panel-heading" id="headingFour" role="tab">
                                                    <h4 class="panel-title">
                                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">04.
                                                            Anonymous user won’t receive
                                                            email private? <i class="pull-right fa fa-plus"></i></a>
                                                    </h4>
                                                </div>
                                                <div class="panel-collapse collapse" id="collapseFour" role="tabpanel" aria-labelledby="headingFour">
                                                    <div class="panel-body pxlr-faq-body">
                                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life
                                                            accusamus terry richardson ad squid. 3 wolf moon officia
                                                            aute,
                                                            non cupidatat skateboard dolor brunch. Food truck quinoa
                                                            nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                                                            aliqua
                                                            put a bird on it esciunt you probably
                                                            haven't heard of them accusamus labore sustainable VHS.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading" id="headingFive" role="tab">
                                                    <h4 class="panel-title">
                                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">05. How to
                                                            have
                                                            an editor like this editor? <i class="pull-right fa fa-plus"></i></a>
                                                    </h4>
                                                </div>
                                                <div class="panel-collapse collapse" id="collapseFive" role="tabpanel" aria-labelledby="headingFive">
                                                    <div class="panel-body pxlr-faq-body">
                                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life
                                                            accusamus terry richardson ad squid. 3 wolf moon officia
                                                            aute,
                                                            non cupidatat skateboard dolor brunch. Food truck quinoa
                                                            nesciunt laborum eiusmod. ea proident. Ad vegan
                                                            excepteur butcher vice lomo. Leggings occaecat craft beer
                                                            farm-to-table, raw denim aesthetic synth nesciunt you
                                                            probably
                                                            haven't heard of them accusamus labore sustainable VHS.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading" id="headingSix" role="tab">
                                                    <h4 class="panel-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">06. Problem
                                                            with Knowledge base Article? <i class="pull-right fa fa-plus"></i></a></h4>
                                                </div>
                                                <div class="panel-collapse collapse" id="collapseSix" role="tabpanel" aria-labelledby="headingSix">
                                                    <div class="panel-body pxlr-faq-body">
                                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life
                                                            accusamus terry richardson ad squid. 3 wolf moon officia
                                                            aute,
                                                            non cupidatat skateboard dolor brunch. Food truck quinoa
                                                            nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                                                            aliqua
                                                            put a bird on it squid single-origin coffee nulla assumenda
                                                            shoreditch et. Nihil anim keffiyeh helvetica, craft beer
                                                            labore
                                                            wes anderson cred nesciunt sapiente ea proident. Ad vegan
                                                            excepteur butcher vice lomo. Leggings occaecat craft beer
                                                            farm-to-table, raw denim aesthetic synth nesciunt you
                                                            probably
                                                            haven't heard of them accusamus labore sustainable VHS.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>




            </div>



            <div class="col-md-5">
                <div id="slider" class="owl-carousel product-slider">

                    <p class="details-para">Call labs is a state-of-art facility offering highest quality diagnostic services at the convenience of your doorstep. We pride ourselves on three things 1) Assured Quality 2) Best Prices 3) Excellent Turn Around Time. We believe in providing the highest level of transparency to our customers. Testimony to the quality is the ISO certification, a gold standard in the quality of diagnostics. Our entire team is dedicated to providing the best customer experience and continuously strives to....</p>


                </div>
            </div>
        </div>



    </div>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\callabs\resources\views/package-details.blade.php ENDPATH**/ ?>