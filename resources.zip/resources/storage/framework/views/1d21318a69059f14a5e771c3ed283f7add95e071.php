 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta name="description" content="">
 <meta name="author" content="">


 <title>Call Labs</title>

 <link rel="shortcut icon" href="<?php echo e(asset('img/Logo.ico')); ?>">
 <!-- css -->
 <link href="<?php echo e(('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
 <link href="<?php echo e(('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" href="<?php echo e(('plugins/cubeportfolio/css/cubeportfolio.min.css')); ?>">
 <link href="<?php echo e(('css/nivo-lightbox.css')); ?>" rel="stylesheet" />
 <link href="<?php echo e(('css/nivo-lightbox-theme/default/default.css')); ?>" rel="stylesheet" type="text/css" />
 <link href="<?php echo e(('css/owl.carousel.css')); ?>" rel="stylesheet" media="screen" />
 <link href="<?php echo e(('css/owl.theme.css')); ?>" rel="stylesheet" media="screen" />
 <link href="<?php echo e(('css/animate.css')); ?>" rel="stylesheet" />
 <link href="<?php echo e(('css/style.css')); ?>" rel="stylesheet">



 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">


 <link id="bodybg" href="<?php echo e(('bodybg/bg1.css')); ?>" rel="stylesheet" type="text/css" />
 <!-- template skin -->
 <link id="t-colors" href="<?php echo e(('color/default.css')); ?>" rel="stylesheet">


 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

 <?php /**PATH C:\xampp\htdocs\callabs\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>