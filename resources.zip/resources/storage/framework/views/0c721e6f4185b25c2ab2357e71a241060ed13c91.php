<link href="<?php echo e(('css/advertise.css')); ?>" rel="stylesheet">

<div id="banner">
            <a href="/">
                <div id="target"></div>
                <img id="product" src="img/boxes/g5.jpg">
                <div id="badge">SAVE NOW!</div>
                <div id="sale">
                    <span id="sale-text">30% off All Lab Tests</span><br/>
                    <span id="button">CALL LABS</span>
                </div>
            </a>
        </div><?php /**PATH C:\xampp\htdocs\callabs\resources\views/layouts/advertise.blade.php ENDPATH**/ ?>