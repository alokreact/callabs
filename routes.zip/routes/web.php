<?php

use Illuminate\Support\Facades\Route;

// Home Page Routes
Route::get('/', 'FrontEndController@index');
Route::get('/new-appointment/{doctorId}/{date}', 'FrontEndController@show')->name('create.appointment');
Route::get('/dashboard', 'DashBoardController@index');

Route::get('/home', 'HomeController@index');
Route::get('/frontend-login', 'FrontendLogInController@index');
Route::get('/frontend-signup', 'FrontendLogInController@signup');

Route::get('package/{id}', 'FrontEndController@package')->name('package-details');
Route::get('listing', 'ListingController@index')->name('listing');
Route::post('search-test', 'ListingController@search')->name('search-test');


Route::get('add-to-cart/{evt}/{id}/{subtest_id}', 'FrontEndController@addToCart')->name('add_to_cart');
Route::get('cart', 'FrontEndController@cart')->name('cart');


Route::get('session/remove', 'FrontEndController@deleteSessionData')->name('session');
Route::delete('remove-from-cart', 'FrontEndController@remove')->name('remove_from_cart');
Route::any('getAjaxtests', 'FrontEndController@getajaxTest')->name('getajaxTest');


Route::get('about', 'ListingController@about')->name('about');
Route::post('user-signup', 'FrontendLogInController@create')->name('user-signup');
Route::post('user-login', 'FrontendLogInController@userlogin')->name('user-login');

Route::get('checkout', 'FrontendLogInController@checkout')->name('checkout');

Route::post('payment', 'FrontendLogInController@iniitiate')->name('payment');

Route::any('success', 'FrontendLogInController@success')->name('success');

Route::get('organs/{id}', 'FrontendLogInController@forntendshow')->name('organs.details');

Route::get('lab/{id}', 'FrontendLogInController@showlab')->name('show.labs');

Route::post('addpatient', 'FrontEndController@addPatient')->name('patient.create');

Auth::routes();

// Patient Routes
Route::group(['middleware' => ['auth', 'patient']], function () {
    // Profile Routes
    Route::get('/user-profile', 'ProfileController@index')->name('profile');
    Route::post('/user-profile', 'ProfileController@store')->name('profile.store');
    Route::post('/profile-pic', 'ProfileController@profilePic')->name('profile.pic');

    Route::post('/book/appointment', 'FrontEndController@store')->name('book.appointment');
    Route::get('/my-booking', 'FrontEndController@myBookings')->name('my.booking');
    Route::get('/my-prescription', 'FrontEndController@myPrescription')->name('my.prescription');
});
// Admin Routes
Route::group(['middleware' => ['auth', 'admin']], function () {
    Route::resource('doctor', 'DoctorController');
    Route::get('/patients', 'PatientListController@index')->name('patients');
    Route::get('/status/update/{id}', 'PatientListController@toggleStatus')->name('update.status');

    Route::get('/all-patients', 'PatientListController@allTimeAppointment')->name('all.appointments');
    Route::resource('/department', 'DepartmentController');
    Route::get('/test', 'TestController@create')->name('test.create');
    Route::post('/test-store', 'TestController@store')->name('test.store');

    Route::get('/category', 'CategoryController@index')->name('category.create');
    Route::post('/category-store', 'CategoryController@store')->name('category.store');
    Route::get('/category-show', 'CategoryController@show')->name('category.show');
    Route::get('/category-edit/{id}', 'CategoryController@edit')->name('category.edit');
    Route::post('/category-update/{id}', 'CategoryController@update')->name('category.update');
    Route::post('/category-destroy/{id}', 'CategoryController@destroy')->name('category.destroy');

    Route::get('/lab', 'LabController@index')->name('lab.create');
    Route::post('/lab-store', 'LabController@store')->name('lab.store');
    Route::get('/all-labs', 'LabController@show')->name('lab.show');
    Route::get('/lab-edit/{id}', 'LabController@edit')->name('lab.edit');
    Route::post('/lab-update/{id}', 'LabController@update')->name('lab.update');
    Route::delete('/lab-destroy/{id}', 'LabController@destroy')->name('lab.destroy');
    Route::get('/labpackage', 'LabController@labpackage')->name('lab.package');
    Route::post('/labpackage-store', 'LabController@storelabpackage')->name('labpackage.store');
    Route::get('/labpackage-show', 'LabController@showlabpackage')->name('labpackage.show');
    Route::get('/labpackage-edit/{id}', 'LabController@labpackagedit')->name('labpackage.edit');
    Route::post('/labpackage-update/{id}', 'LabController@labpackageupdate')->name('labpackage.update');


    //  Route::resource('/lab', 'LabController');

    Route::resource('/testbyorgan', 'TestByOrganController');
    Route::resource('/organ', 'OrganController');

    Route::get('/organ-test', 'TestByOrganController@forntendshow')->name('organ-test'); 
    Route::get('/organtest-edit/{organ_id}', 'TestByOrganController@organtestedit')->name('organtest.edit');

    
    Route::post('/organtest-update/{organ_id}', 'TestByOrganController@organtestupdate')->name('organtest.update');


    Route::get('/sub-test', 'TestController@subtest')->name('subtest.create');
    Route::post('/sub-test-store', 'TestController@subteststore')->name('subtest.store');
    Route::get('/sub-test-show', 'TestController@subtestshow')->name('subtest.show');
    Route::get('/sub-test-edit/{id}', 'TestController@findsubtest')->name('subtest.find');
    Route::get('/subtest-edit/{id}', 'TestController@subtestedit')->name('subtest.edit');
    Route::post('/subtest-update/{id}', 'TestController@subtestupdate')->name('subtest.update');
    Route::delete('/subtest-destroy/{id}', 'TestController@subtestdestroy')->name('subtest.destroy');


    Route::get('/parent-test', 'TestController@parenttest')->name('parenttest.create');
    Route::post('/parent-test-store', 'TestController@parentteststore')->name('parenttest.store');
    Route::get('/parent-test-show', 'TestController@parenttestshow')->name('parenttest.show');
    Route::get('/parent-test-edit/{id}', 'TestController@parenttestedit')->name('parenttest.edit');
    Route::post('/parent-test-update/{id}', 'TestController@parenttestupdate')->name('parenttest.update');


    Route::get('/package-show', 'TestController@package')->name('package.show');
    Route::get('/package-edit/{id}', 'TestController@edit')->name('package.edit');
    Route::post('/package-update/{id}', 'TestController@update')->name('package.update');

    Route::post('/package-destroy/{id}', 'TestController@packagedestroy')->name('package.destroy');
   
    Route::get('/users', 'UserController@index')->name('users');
   
});

// Doctor Routes
Route::group(['middleware' => ['auth', 'doctor']], function () {
    Route::resource('appointment', 'AppointmentController');
    Route::post('/appointment/check', 'AppointmentController@check')->name('appointment.check');
    Route::post('/appointment/update', 'AppointmentController@updateTime')->name('update');
    Route::get('patient-today', 'PrescriptionController@index')->name('patient.today');
    Route::post('prescription', 'PrescriptionController@store')->name('prescription');
    Route::get('/prescription/{userId}/{date}', 'PrescriptionController@show')->name('prescription.show');
    Route::get('/all-prescriptions', 'PrescriptionController@showAllPrescriptions')->name('all.prescriptions');
});
